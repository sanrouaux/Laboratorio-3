<?php

sleep(3);

var_dump($_REQUEST);